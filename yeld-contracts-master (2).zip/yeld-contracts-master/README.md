# The official Yeld yield application

The contracts are in development. Based on the open source contracts from yearn.finance, we'll implement our innovative algorithms on top of their solid and audited codebase.

# Addresses

YELD coin token -> 0x468ab3b1f63A1C14b361bC367c3cC92277588Da1

YeldDAI (Yeld Earning Token) -> 0x3E5723C9040D24E7fb4be9f9849F73dD6305204A

RetirementYeldTreasury -> 0x6F3463baC33383A42E666D07E37e17Df1d3D70fD

yDAI -> 0x39eE9b9EA9e4b9Cc90747Ab4714a7ffcc59f313F